# To-Do List App

## Description
This is a simple web-based To-Do List application built using HTML, CSS, and JavaScript. It allows users to add, edit, delete, and mark tasks as completed. Tasks are saved in local storage to persist even after refreshing the page.

## Features
- **Add New Tasks:** Enter a task in the input field and click "Add" to add it to the list.
- **Mark Tasks as Completed:** Check the checkbox to mark a task as done.
- **Delete Tasks:** Click the "Delete" button to remove tasks from the list.
- **Responsive Design:** The app adjusts to different screen sizes for mobile and desktop views.

## Installation
1. **Clone or Download:** Clone the repository or download the project files.
2. **Open in Browser:** Open the `index.html` file in a web browser. You can also use a local server (e.g., Live Server in Visual Studio Code) to view the application.

## Usage
1. **Adding Tasks:** Type a task in the input field and click "Add" to add it to the task list.
2. **Completing Tasks:** Check the checkbox next to a task to mark it as completed. Uncheck it to revert the status.
3. **Deleting Tasks:** Click the "Delete" button next to a task to remove it from the list.

## Dependencies
This project does not use any external libraries or frameworks.

## License
This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

## Contact
For any questions or feedback, please contact [your-email@example.com](mailto:your-email@example.com).
![Screenshot](path/to/screenshot.png)
![Build Status](https://img.shields.io/badge/build-passing-brightgreen)
